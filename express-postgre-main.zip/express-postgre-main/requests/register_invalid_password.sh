
curl -X POST http://localhost:8080/register \
     -H "Content-Type: application/json" \
     -d '{"name": "Carlos", "email": "carlos@example.com", "password": "123"}' # Senha muito simples
