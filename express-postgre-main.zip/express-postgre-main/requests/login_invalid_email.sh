
curl -X POST http://localhost:8080/login \
     -H "Content-Type: application/json" \
     -d '{"email": "joaoexample.com", "password": "Senha123"}'
