
curl -X GET http://localhost:8080/protected
