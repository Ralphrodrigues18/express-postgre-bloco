const protecao = (req, res) => {
    return res.status(200).json({menssage: "Liberado."})
}
export default {protecao}